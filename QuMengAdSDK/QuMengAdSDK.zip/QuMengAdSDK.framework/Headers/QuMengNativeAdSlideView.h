//
//  QuMengNativeAdSlideView.h
//  QuMengAdSDK
//
//  Created by Donnie on 2025/2/13.
//

#import <UIKit/UIKit.h>

#import <QuMengAdSDK/QuMengNativeAd.h>

NS_ASSUME_NONNULL_BEGIN

@interface QuMengNativeAdSlideView : UIView

@property (nonatomic, strong) QuMengNativeAd *nativeAd;

@end

NS_ASSUME_NONNULL_END
